var  sql = 'SELECT * FROM user';


module.exports = sql
